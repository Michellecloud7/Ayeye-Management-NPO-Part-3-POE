document.addEventListener('DOMContentLoaded', () => {
  // Accessible responsive navigation
  const toggle = document.querySelector('.menu-toggle');
  const nav = document.querySelector('.nav-links');
  if (toggle && nav) {
    toggle.addEventListener('click', () => {
      const isOpen = nav.classList.toggle('open');
      toggle.setAttribute('aria-expanded', String(isOpen));
      toggle.setAttribute('aria-label', isOpen ? 'Close navigation' : 'Open navigation');
    });
    nav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
      nav.classList.remove('open');
      toggle.setAttribute('aria-expanded', 'false');
      toggle.setAttribute('aria-label', 'Open navigation');
    }));
  }

  // Client-side validation and asynchronous Netlify form submission.
  document.querySelectorAll('[data-ajax-form]').forEach(form => {
    form.addEventListener('submit', async event => {
      event.preventDefault();
      const status = form.querySelector('.form-message');
      if (!form.reportValidity()) return;
      if (status) { status.hidden = false; status.textContent = 'Sending your message…'; }
      const submit = form.querySelector('[type="submit"]');
      if (submit) submit.disabled = true;
      try {
        const body = new URLSearchParams(new FormData(form)).toString();
        const response = await fetch('/', {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body
        });
        if (!response.ok) throw new Error('Form service unavailable');
        if (status) status.textContent = 'Thank you! Your message has been submitted to Ayeye Management.';
        form.reset();
      } catch (error) {
        // Local preview fallback: prepare an email in the visitor's mail application.
        const data = new FormData(form);
        const subject = encodeURIComponent(data.get('subject') || `Website enquiry: ${data.get('interest') || 'General'}`);
        const lines = [
          `Name: ${data.get('name') || ''}`,
          `Email: ${data.get('email') || ''}`,
          `Phone: ${data.get('phone') || ''}`,
          `Enquiry type: ${data.get('interest') || ''}`,
          '', data.get('message') || ''
        ];
        const mailto = `mailto:michelle00785mudau@gmail.com?subject=${subject}&body=${encodeURIComponent(lines.join('\n'))}`;
        if (status) status.textContent = 'The online form service is not connected in this preview. Your email application will open with the enquiry prepared.';
        window.location.href = mailto;
      } finally {
        if (submit) submit.disabled = false;
      }
    });
  });

  // Gallery filtering by accessible image captions/alt text.
  const search = document.querySelector('[data-gallery-search]');
  if (search) {
    const cards = [...document.querySelectorAll('.gallery-grid > *, .grid-3 > .card, .gallery-item')];
    search.addEventListener('input', () => {
      const term = search.value.trim().toLowerCase();
      cards.forEach(card => {
        const text = `${card.textContent} ${[...card.querySelectorAll('img')].map(img => img.alt).join(' ')}`.toLowerCase();
        card.hidden = !text.includes(term);
      });
    });
  }

  // Accessible gallery lightbox; opens when a gallery image is selected.
  const lightbox = document.getElementById('gallery-lightbox');
  const lightboxImage = document.getElementById('lightbox-image');
  const caption = document.getElementById('lightbox-caption');
  if (lightbox && lightboxImage) {
    document.querySelectorAll('.gallery-grid img, .gallery-item img').forEach(img => {
      img.tabIndex = 0;
      img.setAttribute('role', 'button');
      img.setAttribute('aria-label', `View larger image: ${img.alt || 'Gallery image'}`);
      const open = () => {
        lightboxImage.src = img.currentSrc || img.src;
        lightboxImage.alt = img.alt;
        if (caption) caption.textContent = img.alt;
        if (typeof lightbox.showModal === 'function') lightbox.showModal();
      };
      img.addEventListener('click', open);
      img.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); open(); } });
    });
    lightbox.querySelector('.lightbox-close')?.addEventListener('click', () => lightbox.close());
    lightbox.addEventListener('click', e => { if (e.target === lightbox) lightbox.close(); });
  }

  // Small accordion enhancement for any FAQ/details elements included on pages.
  document.querySelectorAll('[data-accordion-trigger]').forEach(trigger => {
    trigger.addEventListener('click', () => {
      const panel = document.getElementById(trigger.getAttribute('aria-controls'));
      const expanded = trigger.getAttribute('aria-expanded') === 'true';
      trigger.setAttribute('aria-expanded', String(!expanded));
      if (panel) panel.hidden = expanded;
    });
  });

  // Dynamic programme/event search and category filtering.
  ['programmes', 'events'].forEach(type => {
    const list = document.querySelector(`[data-content-list="${type}"]`);
    if (!list) return;
    const cards = [...list.children];
    const searchInput = document.querySelector(`[data-content-search="${type}"]`);
    const categorySelect = document.querySelector(`[data-content-filter="${type}"]`);
    const count = document.querySelector(`[data-results-count="${type}"]`);
    const filter = () => {
      const term = (searchInput?.value || '').trim().toLowerCase();
      const category = categorySelect?.value || 'all';
      let visible = 0;
      cards.forEach(card => {
        const matchesText = card.textContent.toLowerCase().includes(term);
        const matchesCategory = category === 'all' || card.dataset.category === category;
        const show = matchesText && matchesCategory;
        card.hidden = !show;
        if (show) visible++;
      });
      if (count) count.textContent = `Showing ${visible} of ${cards.length} ${type}.`;
    };
    searchInput?.addEventListener('input', filter);
    categorySelect?.addEventListener('change', filter);
  });

  // Subtle scroll-reveal animation, with reduced-motion support.
  if ('IntersectionObserver' in window && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    const revealItems = document.querySelectorAll('.card, .event, .section-title, .cta');
    revealItems.forEach(item => item.classList.add('reveal-pending'));
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });
    revealItems.forEach(item => observer.observe(item));
  }

});
