# Ayeye Management NPO Website

## 1. Project overview
This responsive website prototype was created for Ayeye Management NPO. It presents the organisation's mission, vision, programmes, events, gallery, volunteering, donation and contact information.

**Slogan:** “Fueling futures, Defying odds”

## 2. Pages
- `index.html` – Home
- `about.html` – About Us
- `programmes.html` – Programmes
- `events.html` – Events
- `get-involved.html` – Get Involved
- `donate.html` – Donate
- `gallery.html` – Gallery
- `contact.html` – Contact
- `enquiry.html` – Enquiry form for services, products, volunteering, sponsorship and partnerships

## 3. Technical implementation against the brief
### External stylesheet
All pages use the shared external `style.css` file. A consistent naming convention is used with reusable classes such as `.container`, `.grid-3`, `.card`, `.btn` and `.section`.

### Base style and reset
The stylesheet includes a CSS reset using the universal selector and establishes the default font family, font size, colours, line height, margin and padding. CSS variables keep the colour palette consistent.

### Typography
The site uses `font-family`, `font-size`, `font-weight`, `line-height` and `letter-spacing`. Headings use responsive `clamp()` typography to scale across devices.

### Layout structure
CSS Grid is used for cards, statistics, forms, gallery sections and footer columns. Flexbox is used for the header/navigation, buttons and event components.

### Visual styles and pseudo-classes
The site uses `color`, `background-color`, `border` and `box-shadow`. Interactive states include `:hover`, `:focus-visible` and `:active` for navigation, buttons, cards and form controls.

## 4. Responsive design
Two main breakpoints are implemented:
- **Tablet:** `max-width: 56.25rem` – navigation changes to a menu, grids reduce columns and the two-column content layout becomes stacked.
- **Mobile:** `max-width: 40.625rem` – content becomes single-column, typography and logo sizes reduce, buttons become full width and the footer stacks vertically.

Relative units such as `rem`, `em`-compatible sizing, `%`, `vw`, `clamp()` and `min()` are used to support responsive layouts.

## 5. Responsive images
The Home and Gallery pages use the `<picture>` element and `sizes`/`srcset` attributes. Gallery images are stored locally in `assets/` and use lazy loading.

## 6. Gallery assets
The `assets/` folder contains the supplied Ayeye logo and locally stored activity illustrations. The illustrations can be replaced with approved organisation photographs without changing the HTML layout.

## 7. Wireframes
Low-fidelity wireframes are included in `wireframes/`:
- `desktop-wireframe.svg`
- `mobile-wireframe.svg`

## 8. Testing and iteration
The website should be tested using browser developer tools at desktop, tablet and mobile viewport sizes. Check navigation, buttons, forms, images, text wrapping and horizontal scrolling at each size.

### Suggested screenshot evidence
Include screenshots in the final assignment/README showing:
1. Desktop Home page.
2. Tablet Home page.
3. Mobile Home page.
4. Mobile navigation menu open.
5. Gallery page at desktop/mobile sizes.
6. Contact form and responsive layout.

## 9. Suggested GitHub commits
1. Create Ayeye Management homepage and shared stylesheet
2. Add About Us and Programmes pages
3. Add Events, Get Involved and Donate pages
4. Add Gallery and Contact pages
5. Implement CSS Grid, Flexbox and responsive breakpoints
6. Add responsive images and accessibility improvements
7. Test desktop, tablet and mobile layouts
8. Update README with testing evidence

## 10. Important project note
This is a student website prototype. Replace sample event dates, donation/payment details, email/domain details and illustrative gallery assets with verified information supplied by Ayeye Management NPO before publishing publicly.


## 11. Part 3 – JavaScript functionality and SEO
### JavaScript enhancements
- Programme search and category filters dynamically show/hide matching programme cards.
- Event search and category filters dynamically show/hide matching event listings.
- Scroll-reveal animations use Intersection Observer and respect reduced-motion preferences.
- Responsive navigation toggles with `aria-expanded` state.
- About page FAQ accordion controls reveal/hide answers.
- Gallery images open in an accessible modal lightbox and can be opened with the keyboard.
- Gallery search filters visible image cards using captions and alternative text.
- Contact and enquiry forms use native HTML constraints plus JavaScript `reportValidity()` and asynchronous form submission.

### Form purpose and fields
- `enquiry.html`: dedicated enquiry form for services, products, volunteering, sponsorship, partnerships and programmes, with name, email, phone, enquiry type and message.
- `contact.html`: general message form with name, email, optional phone, subject and message.
- `get-involved.html`: enquiry form for volunteering, partnerships, sponsorship, skills support, outreach and programme/service enquiries.
- Both forms are configured for Netlify Forms (`data-netlify="true"`) and use AJAX-style submission. A mailto fallback is provided for local previews.

**Form notification setup:** the forms submit to Netlify when the site is deployed there. In the Netlify site dashboard, enable form detection/redeploy if prompted, then configure form notification emails to **michelle00785mudau@gmail.com** for both `contact` and `enquiry`. The recipient address is also used by the local-preview mailto fallback. A static website cannot securely send email directly without a form service or backend.

### SEO implementation
- Page-specific titles, meta descriptions and keyword metadata.
- Semantic heading structure, descriptive image alt text and internal links.
- Descriptive page filenames and mobile-friendly responsive layouts.
- NGO structured data on the homepage (JSON-LD).
- `robots.txt` and `sitemap.xml` included. Replace `YOUR-PUBLISHED-DOMAIN` in both files with the actual Netlify/custom domain after deployment.
- Off-page SEO recommendations: publish verified organisation updates on social media and seek relevant links from partner/community organisation websites. Do not purchase spam backlinks.

### Performance and security notes
- JavaScript is loaded with `defer`; images should retain lazy loading below the fold.
- Netlify configuration includes basic security response headers.
- Forms include required fields, email/phone format checks, length limits and a honeypot field. Server-side spam protection and notification rules must be enabled in the hosting/form service.
- Do not collect sensitive personal information through these forms.

### Deployment on Netlify
1. Extract the ZIP. Open the `ayeye_map_update` folder and upload the contents of that folder (HTML files, `style.css`, `script.js`, `assets/`, `wireframes/`, `netlify.toml`, `robots.txt` and `sitemap.xml`) to the root of your GitHub repository.
2. In Netlify, choose **Add new site → Import an existing project** and connect the repository.
3. Set the publish directory to `.` (the included `netlify.toml` also specifies this).
4. Deploy, then submit test messages through both forms.
5. In Netlify Forms, confirm submissions are captured and configure email notifications to **michelle00785mudau@gmail.com**.
6. Replace the placeholder domain in `robots.txt` and `sitemap.xml`, redeploy, and submit the sitemap in Google Search Console.

### Part 3 testing checklist
- [ ] Open and close mobile navigation using mouse and keyboard.
- [ ] Expand/collapse both FAQ items.
- [ ] Search the gallery and confirm non-matching cards are hidden.
- [ ] Open/close gallery lightbox using mouse, Enter/Space and Escape.
- [ ] Submit invalid contact/enquiry data and confirm browser validation blocks it.
- [ ] Search and filter programmes and events by text/category.
- [ ] Confirm scroll-reveal animations and reduced-motion behaviour.
- [ ] Submit valid forms on the deployed Netlify site and confirm dashboard submissions/email notifications.
- [ ] Check page titles, descriptions, image alt text, sitemap and robots file.
- [ ] Test desktop, tablet and mobile layouts and capture screenshots for evidence.

### Part 3 suggested Git commits
1. Add accessible JavaScript navigation and FAQ accordion
2. Add gallery search and lightbox interaction
3. Add validated contact and enquiry forms
4. Configure Netlify form handling and email notifications
5. Add SEO metadata, NGO structured data, sitemap and robots file
6. Add security headers and document deployment/testing
7. Add dedicated enquiry page and dynamic programme/event filters
8. Add accessible scroll-reveal animation and update sitemap


### Remaining items before public launch
- Replace the placeholder domain in `robots.txt` and `sitemap.xml` after the site has a confirmed public URL.
- Verify the event dates and replace any sample dates with Ayeye-approved dates before presenting them as upcoming events.
- Replace illustrative gallery graphics with approved organisation photographs when available.
- Complete the deployed form tests and capture desktop, tablet and mobile screenshots for the assignment.

## Part 3 map update – organisation address
- Contact page now displays the address supplied by Ayeye Management: **4669 6th Avenue, Rietvallei Ext 2, Krugersdorp, 1754, South Africa**.
- Added an interactive Leaflet map using OpenStreetMap tiles. The page geocodes the supplied address at runtime and places a marker only when the geocoder returns a match; it does not hard-code guessed coordinates.
- A direct OpenStreetMap search link remains available if the map service or address lookup is unavailable.
- The map requires an internet connection and the Leaflet/OpenStreetMap services to be available. Verify the marker visually before public launch.
